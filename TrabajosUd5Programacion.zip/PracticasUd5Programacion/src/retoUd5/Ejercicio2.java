package retoUd5;

import java.io.*;
import java.util.Scanner;

public class Ejercicio2 {
	public static void main(String[] args) throws IOException {
		String directorioActual = System.getProperty("user.dir");
		System.out.println("Directorio actual: " + directorioActual);

		File directorio = crearDirectorio(directorioActual, "dirEjer2");
		File fichero1 = crearFichero(directorio, "uno.txt");
		File fichero2 = crearFichero(directorio, "dos.txt");

		escribirEnFichero(fichero1);
		leerDeFichero(fichero2);
	}

	public static boolean comprobarExiste(File fichero) {
		return fichero.exists();
	}

	public static File crearDirectorio(String directorioActual, String nombreDirectorio) {
		File dir = new File(directorioActual + File.separator + nombreDirectorio);
		if (!comprobarExiste(dir)) {
			dir.mkdir();
		}
		
		return dir;
	}

	public static File crearFichero(File directorioActual, String nombreArchivo) throws IOException {
		File fichero = new File(directorioActual.getAbsolutePath() + File.separator + nombreArchivo);
		if (!comprobarExiste(fichero)) {
			fichero.createNewFile();
		}
		return fichero;
	}

	public static void escribirEnFichero(File fichero) throws IOException {
		if (comprobarExiste(fichero)) {
			BufferedWriter writer = new BufferedWriter(new FileWriter(fichero));
			Scanner scanner = new Scanner(System.in);
			String nombre;
			do {
				System.out.println("Introduce un nombre (o '-' para terminar):");
				nombre = scanner.nextLine();
				if (!nombre.equals("-")) {
					writer.write(nombre);
					writer.newLine();
				}
			} while (!nombre.equals("-"));
			writer.close();
		}
	}

	public static void leerDeFichero(File fichero) throws IOException {
		if (comprobarExiste(fichero)) {
			BufferedReader reader = new BufferedReader(new FileReader(fichero));
			String linea;
			while ((linea = reader.readLine()) != null) {
				System.out.println(linea);
			}
			reader.close();
		}
	}
}



