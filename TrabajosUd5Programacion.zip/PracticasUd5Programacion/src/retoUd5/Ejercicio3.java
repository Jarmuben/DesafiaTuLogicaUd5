

package retoUd5;



import java.io.*;
import java.util.Scanner;

public class Ejercicio3 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		try {
			FileOutputStream fos = new FileOutputStream("tres.dat");
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			System.out.println("Introduce números positivos (un número negativo para terminar):");
			while (true) {
				int num = scanner.nextInt();
				if (num < 0) {
					break;
				}
				oos.writeInt(num);
			}

			oos.close();
			fos.close();

			FileInputStream fis = new FileInputStream("tres.dat");
			ObjectInputStream ois = new ObjectInputStream(fis);

			System.out.println("Los números almacenados en el fichero 'tres.dat' son:");
			try {
				while (true) {
					System.out.println(ois.readInt());
				}
			} catch (EOFException e) {
				// Fin de archivo alcanzado
			}

			ois.close();
			fis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}



