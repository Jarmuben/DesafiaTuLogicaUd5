package retoUd5;
import java.io.*;


import java.util.Scanner;
public class Ejercicio1 {


	public class Main {
		public static void main(String[] args) throws IOException {
			Scanner scanner = new Scanner(System.in);
			String nombreArchivo1, nombreArchivo2;

			do {
				System.out.println("Introduce el nombre del primer fichero:");
				nombreArchivo1 = scanner.nextLine();
			} while (nombreArchivo1.length() < 3);
			System.out.println("El nombre del fichero " + nombreArchivo1 + " es válido");

			do {
				System.out.println("Introduce el nombre del segundo fichero:");
				nombreArchivo2 = scanner.nextLine();
			} while (nombreArchivo2.length() < 3);
			System.out.println("El nombre del fichero " + nombreArchivo2 + " es válido");

			String directorioActual = System.getProperty("user.dir");
			System.out.println("Directorio actual: " + directorioActual);
			
			File fichero1 = new File(directorioActual + File.separator + nombreArchivo1);
			File fichero2 = new File(directorioActual + File.separator + nombreArchivo2);

			crearFichero(fichero1);
			crearFichero(fichero2);

			escribirEnFichero(fichero1);
			leerDeFichero(fichero1);
			mostrarPropiedadesFichero(fichero1);

			duplicarFicheros(fichero1, fichero2);
			borrarFichero(fichero1);

			leerDeFichero(fichero2);

			File directorio = new File(directorioActual + File.separator +  "dirEjer1");
			crearDirectorio(directorio);
		}

		public static boolean comprobarExiste(File fichero) {
			return fichero.exists();
		}

		public static void crearFichero(File fichero) throws IOException {
			if (!comprobarExiste(fichero)) {
				fichero.createNewFile();
			} else {
				System.out.println("El fichero " + fichero.getName() + " ya existe");
			}
		}

		public static void escribirEnFichero(File fichero) throws IOException {
			if (comprobarExiste(fichero)) {
				FileWriter writer = new FileWriter(fichero);
				for (int i = 0; i <= 10; i++) {
					writer.write(String.valueOf(i) + "\n");
				}
				writer.close();
			}
		}

		public static void leerDeFichero(File fichero) throws IOException {
			if (comprobarExiste(fichero)) {
				FileReader reader = new FileReader(fichero);
				int i;
				while ((i = reader.read()) != -1) {
					System.out.print((char) i);
				}
				reader.close();
			}
		}

		public static void mostrarPropiedadesFichero(File fichero) {
			if (comprobarExiste(fichero)) {
				System.out.println("Nombre del archivo: " + fichero.getName());
				System.out.println("Ruta absoluta: " + fichero.getAbsolutePath());
				System.out.println("Ruta del directorio padre: " + fichero.getParent());
				System.out.println("Tamaño del fichero: " + fichero.length());
				System.out.println("¿Es un fichero?: " + fichero.isFile());
				System.out.println("Permiso de lectura: " + fichero.canRead());
				System.out.println("Permiso de escritura: " + fichero.canWrite());
				System.out.println("Permiso de ejecución: " + fichero.canExecute());
				System.out.println("¿Está oculto?: " + fichero.isHidden());
			} else {
				System.out.println("El fichero " + fichero.getName() + " no existe");
			}
		}

		public static void duplicarFicheros(File origen,File destino) throws IOException {
			if (comprobarExiste(origen) && comprobarExiste(destino)) {
				InputStream in = new FileInputStream(origen);
				OutputStream out = new FileOutputStream(destino);

				byte[] buffer = new byte[1024];
				int length;
				while ((length = in.read(buffer)) > 0) {
					out.write(buffer, 0, length);
				}
				in.close();
				out.close();
			}
		}

		public static void borrarFichero(File miFichero) {
			if (comprobarExiste(miFichero)) {
				miFichero.delete();
			}
		}

		public static void crearDirectorio(File directorio) {
			if (!comprobarExiste(directorio)) {
				directorio.mkdir();
			}
		}

	}
}



