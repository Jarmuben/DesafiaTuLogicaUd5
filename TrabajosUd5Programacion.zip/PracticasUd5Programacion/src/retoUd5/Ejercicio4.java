package retoUd5;
import java.io.*;
public class Ejercicio4 {
	
	static class Persona implements Serializable {
	    private String nombre;
	    private int edad;
	    private double altura;
	    private double peso;

	    public Persona(String nombre, int edad, double altura, double peso) {
	        this.nombre = nombre;
	        this.edad = edad;
	        this.altura = altura;
	        this.peso = peso;
	    }

	    @Override
	    public String toString() {
	        return "Persona{" +"nombre='" + nombre + '\'' +", edad=" + edad +", altura=" + altura +", peso=" + peso +'}';
	    }
	}


	    public static void main(String[] args) {
	        Persona[] personas = new Persona[]{
	                new Persona("Jesus", 20, 1.75, 60),
	                new Persona("Marta", 35, 1.65, 70),
	                new Persona("Luis", 45, 1.90, 80)
	        };

	        try {
	            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("persona.dat"));
	            for (Persona persona : personas) {
	                oos.writeObject(persona);
	            }
	            oos.close();

	            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("persona.dat"));
	            try {
	                while (true) {
	                    Persona persona = (Persona) ois.readObject();
	                    System.out.println(persona);
	                }
	            } catch (EOFException e) {
	                // Fin de archivo alcanzado
	            } catch (ClassNotFoundException e) {
	                e.printStackTrace();
	            }
	            ois.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}


